<?php 
	$db_con=mysqli_connect("localhost","root","","student_manage");

?>